class FaleConosco {
    constructor(nome, email, assunto, mensagem){
        this._nome = nome;
        this._email = email;
        this._assunto = assunto;
        this._mensagem = mensagem;
    }

    
}